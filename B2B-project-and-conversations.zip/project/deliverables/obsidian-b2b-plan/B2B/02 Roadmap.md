# B2B roadmap

This is a navigation index, not a second task list. Live status comes from the checkbox and tag in each task note.

## Foundation

- [[B2B/Tasks/B2B-001|B2B-001 — Choose the main execution architecture]]
- [[B2B/Tasks/B2B-002|B2B-002 — Record the current runtime and startup commands]]
- [[B2B/Tasks/B2B-003|B2B-003 — Restore the selected local runtime]]
- [[B2B/Tasks/B2B-004|B2B-004 — Make the Flowise test harness portable]]
- [[B2B/Tasks/B2B-005|B2B-005 — Create a small reusable fixture pack]]
- [[B2B/Tasks/B2B-006|B2B-006 — Agree versioned application request and response contracts]]

## Campaigns

- [[B2B/Tasks/B2B-007|B2B-007 — Verify campaign intake validation and limits]]
- [[B2B/Tasks/B2B-008|B2B-008 — Add asynchronous campaign job intake]]

## Discovery

- [[B2B/Tasks/B2B-009|B2B-009 — Verify multilingual research planning]]
- [[B2B/Tasks/B2B-010|B2B-010 — Validate candidate relevance decisions]]
- [[B2B/Tasks/B2B-011|B2B-011 — Verify live B2B.tn discovery]]
- [[B2B/Tasks/B2B-012|B2B-012 — Implement a configured web search source]]
- [[B2B/Tasks/B2B-013|B2B-013 — Verify the optional Google Maps adapter]]
- [[B2B/Tasks/B2B-014|B2B-014 — Meet the three-source-type discovery criterion]]
- [[B2B/Tasks/B2B-015|B2B-015 — Verify provenance on collected records]]

## Identity

- [[B2B/Tasks/B2B-016|B2B-016 — Run existing candidate-normalization regression]]
- [[B2B/Tasks/B2B-017|B2B-017 — Run existing RNE-policy regression]]
- [[B2B/Tasks/B2B-020|B2B-020 — Cover conflicting IDs and placeholder contacts]]
- [[B2B/Tasks/B2B-021|B2B-021 — Persist ambiguous matches for human review]]
- [[B2B/Tasks/B2B-027|B2B-027 — Validate official RNE mapping and live lookup]]

## Scoring and offers

- [[B2B/Tasks/B2B-018|B2B-018 — Run existing lead-scoring regression]]
- [[B2B/Tasks/B2B-019|B2B-019 — Run existing offer-recommendation regression]]
- [[B2B/Tasks/B2B-029|B2B-029 — Import and validate the official catalog]]
- [[B2B/Tasks/B2B-030|B2B-030 — Add scoring boundary and missing-data cases]]
- [[B2B/Tasks/B2B-031|B2B-031 — Review scoring and offer relevance with sales]]

## Enrichment

- [[B2B/Tasks/B2B-022|B2B-022 — Verify website collection limits and unsafe URLs]]
- [[B2B/Tasks/B2B-023|B2B-023 — Verify evidence-grounded fact extraction]]
- [[B2B/Tasks/B2B-024|B2B-024 — Implement field precedence and visible conflicts]]
- [[B2B/Tasks/B2B-025|B2B-025 — Verify completeness and readiness indicators]]

## External dependencies

- [[B2B/Tasks/B2B-026|B2B-026 — Obtain official RNE integration details]]
- [[B2B/Tasks/B2B-028|B2B-028 — Obtain the official Orange product catalog]]

## Sales support

- [[B2B/Tasks/B2B-032|B2B-032 — Verify the DME company assistant]]
- [[B2B/Tasks/B2B-033|B2B-033 — Verify visit-report cleaning and evidence]]
- [[B2B/Tasks/B2B-034|B2B-034 — Verify risk rules and credential redaction]]

## AI reliability

- [[B2B/Tasks/B2B-035|B2B-035 — Verify AI output schemas and bounded repair]]
- [[B2B/Tasks/B2B-036|B2B-036 — Design and test model-outage recovery]]
- [[B2B/Tasks/B2B-037|B2B-037 — Run adversarial extraction and prompt tests]]

## Acceptance

- [[B2B/Tasks/B2B-038|B2B-038 — Run one deterministic end-to-end campaign]]
- [[B2B/Tasks/B2B-039|B2B-039 — Run the AI-enabled end-to-end acceptance path]]

## Data and backend

- [[B2B/Tasks/B2B-040|B2B-040 — Agree the persistent business data model]]
- [[B2B/Tasks/B2B-041|B2B-041 — Persist validated company and evidence outputs]]
- [[B2B/Tasks/B2B-042|B2B-042 — Verify replay and concurrent-write idempotency]]
- [[B2B/Tasks/B2B-043|B2B-043 — Implement reviewed conflict resolution]]

## Application integration

- [[B2B/Tasks/B2B-044|B2B-044 — Define and enforce application role access]]
- [[B2B/Tasks/B2B-045|B2B-045 — Connect the admin campaign form and status view]]
- [[B2B/Tasks/B2B-046|B2B-046 — Build the company profile evidence view]]
- [[B2B/Tasks/B2B-047|B2B-047 — Connect DME visit preparation to the assistant]]
- [[B2B/Tasks/B2B-048|B2B-048 — Connect editable report review and saving]]
- [[B2B/Tasks/B2B-049|B2B-049 — Build the human-review queue screen]]
- [[B2B/Tasks/B2B-050|B2B-050 — Confirm and implement manual prospect assignment]]
- [[B2B/Tasks/B2B-051|B2B-051 — Confirm visit tracking and follow-up scope]]

## Operations

- [[B2B/Tasks/B2B-052|B2B-052 — Add correlated execution and audit logs]]
- [[B2B/Tasks/B2B-053|B2B-053 — Measure pipeline quality and latency]]
- [[B2B/Tasks/B2B-054|B2B-054 — Set secret handling and trace retention rules]]
- [[B2B/Tasks/B2B-055|B2B-055 — Implement bounded retries and job cancellation]]
- [[B2B/Tasks/B2B-056|B2B-056 — Add scheduled discovery after manual jobs work]]

## Delivery

- [[B2B/Tasks/B2B-057|B2B-057 — Package a reproducible staging deployment]]
- [[B2B/Tasks/B2B-058|B2B-058 — Verify backup restore and rollback]]
- [[B2B/Tasks/B2B-059|B2B-059 — Run a bounded DME pilot acceptance session]]
- [[B2B/Tasks/B2B-060|B2B-060 — Prepare the demonstration and handover guide]]
