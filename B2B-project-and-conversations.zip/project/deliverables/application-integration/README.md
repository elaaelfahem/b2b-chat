# Updated integrated application (13 October 2026)

Backend and frontend ZIPs contain the supplied applications with the AI integration and latest fixes. Runtime ZIP contains the corresponding AI repository updates. Patches compare the source against the original supplied ZIPs. Dependencies, builds and local credentials are excluded.

Fixed: model-enabled assistant/report cleanup, sector search aliases, interrupted campaign/collection recovery, empty-search handling and missing database migrations. See verification.json and AI_INTEGRATION.md for configuration, tests and remaining external-service limitations. RNE was left unchanged. No GitHub push or public deployment was performed.
