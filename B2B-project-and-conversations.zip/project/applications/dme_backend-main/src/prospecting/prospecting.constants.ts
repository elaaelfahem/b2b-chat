// The lead-scoring model's own bands: 50 is where it marks a company ready for
// an offer recommendation (category B), 75 is its top band (category A).
export const QUALIFIED_AI_SCORE = 50;
export const PRIORITY_AI_SCORE = 75;
