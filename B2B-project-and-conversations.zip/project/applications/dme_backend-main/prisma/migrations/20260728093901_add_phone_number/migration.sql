ALTER TABLE "superadmins" ADD COLUMN     "phone" VARCHAR(30);

ALTER TABLE "users" ADD COLUMN     "phone" VARCHAR(30);
