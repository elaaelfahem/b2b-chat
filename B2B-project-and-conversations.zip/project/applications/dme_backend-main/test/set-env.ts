process.env.NODE_ENV = 'test';
process.env.DATABASE_URL = '[REDACTED]';
process.env.JWT_ACCESS_SECRET = '[REDACTED]';
process.env.JWT_REFRESH_SECRET = '[REDACTED]';
process.env.COOKIE_SECURE = 'false';
process.env.SESSION_IDLE_TIMEOUT_MS = '12000';
process.env.TOUCH_INTERVAL_MS = '1000';
