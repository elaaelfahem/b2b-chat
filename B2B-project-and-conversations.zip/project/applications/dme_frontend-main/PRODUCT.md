# Product

## Register

product

## Users

Orange DME administrators manage manager and agent accounts from a secure back-office workspace. They need a quick overview of account counts, searchable user records, invitation status, and safe account actions.

## Product Purpose

The workspace centralizes access administration for the DME platform. Success means an administrator can understand the current account state at a glance, add or invite users, and perform sensitive actions with clear confirmation and feedback.

## Brand Personality

Direct, operational, dependable. The interface should feel precise and familiar to Orange teams while keeping sensitive actions unambiguous.

## Anti-references

Avoid decorative SaaS dashboards, floating glass cards, excessive rounded corners, gradients, and ambiguous destructive actions. Avoid hiding account status or action feedback.

## Design Principles

- Make account state visible before actions are taken.
- Keep high-frequency administration tasks dense and scannable.
- Separate routine controls from destructive actions.
- Confirm sensitive changes and report the result in context.
- Preserve the Orange DME visual language across future workspace pages.

## Accessibility & Inclusion

Use semantic controls, visible focus states, readable contrast, keyboard-accessible dialogs and menus, responsive layouts, and reduced-motion behavior. Do not rely on color alone to communicate status.
