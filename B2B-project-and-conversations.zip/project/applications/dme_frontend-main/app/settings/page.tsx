import { AppShell } from '@/components/workspace/app-shell';
import { SettingsPage } from '@/components/settings/settings-page';

export default function Settings() {
  return (
    <AppShell>
      <SettingsPage />
    </AppShell>
  );
}
