import { AppShell } from '@/components/workspace/app-shell';
import { MyProfile } from '@/components/user-profile/my-profile';

export default function ProfilePage() {
  return (
    <AppShell>
      <MyProfile />
    </AppShell>
  );
}
