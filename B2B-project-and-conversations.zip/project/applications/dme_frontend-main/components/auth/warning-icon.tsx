export function WarningIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true">
      <path d="M12 3 2 20h20L12 3Z" fill="currentColor" />
      <line
        x1="12"
        y1="10"
        x2="12"
        y2="14"
        stroke="white"
        strokeWidth="2"
        strokeLinecap="round"
      />
      <circle cx="12" cy="17" r="1" fill="white" />
    </svg>
  );
}
