export const DEBUG_SKELETON = process.env.NEXT_PUBLIC_DEBUG_SKELETON === 'true';
