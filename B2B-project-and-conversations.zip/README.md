# B2B project and conversation backup

Snapshot prepared on 2026-10-24 for the Linux-to-Windows move.

- `project/`: current source files, documentation, deliverables, and uncommitted mobile app changes.
- `conversations/`: recovered local B2B Codex user/assistant message transcripts, including related integration tasks and this migration discussion. See `index.json`.

## Continue on Windows

Clone this repository, open `project/` in your editor, and read its README and deployment documentation. Give your assistant the relevant conversation exports to restore context. These Markdown exports do not automatically restore native Codex tasks.

## Backup limits

This is a sanitized snapshot, not a complete machine backup. Credentials and private environment files, dependencies/build caches, databases and Docker volumes, internal tool traces, and original Git history are excluded. Some matching local sessions may be agent subtasks. Attachments referenced by chats are not embedded unless present among the project files. Earlier compacted messages or ChatGPT-only conversations may not be present in these local archives. Keep the Linux installation until private configuration and database migration are handled separately.

The original project Git remote is https://github.com/Orange-Summer-Challenge-2026-Tunisia/DME_AI.git . Its local working tree was not modified by this export.
